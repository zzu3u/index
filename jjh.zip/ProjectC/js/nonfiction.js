$(document).ready(function(){
    $(".title").click(function(){
        $(".title, .content").removeClass('on');
        $(this).toggleClass('on');
        $("#"+$(this).data('id')).toggleClass('on');
        $(".nav").show();
        $(".visual").hide();
    });
    $(".click").click(function(){
        $("title").toggle()
    });
    $(".logo").click(function(){
        $(".title").removeClass('on');
        $(".nav").hide();
        $(".visual").show();
    });
    $(".ti2").click(function(){
        $(".n1").hide();
        $(".n3").hide();
    });
    $(".ti3").click(function(){
        $(".n2").hide();
        $(".n1").hide();
    });
    $(".ti1").click(function(){
        $(".n2").hide();
        $(".n3").hide();
    });
});
$('.visual').vegas({
    slides: [
      { src: "../images/main3.jpg", delay: 3500 },
      { src: "../images/main2.jpg", delay: 3500 },
      { src: "../images/main5.jpg", delay: 3500 },
      { src: "../images/main6.jpg", delay: 3500 },
      { src: "../images/main7.jpg", delay: 3500 },
      { src: "../images/main8.jpg", delay: 3500 },
    ],
    overlay: '../lib/vegas/overlays/03.png',
    // animation: [ 'kenburnsDownLeft', 'kenburnsUpLeft', 'kenburnsUp' ]
    transition: ['fade'],
    animation: 'kenburnsDown'
});
$.vegas.isVideoCompatible = function () {
    var devices = /(Android|webOS|Phone|iPad|iPod|BlackBerry|Windows Phone)/i;
    return !devices.test(navigator.userAgent);
}