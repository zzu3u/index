var swiper = new Swiper('.swiper-container', {
    spaceBetween: 30,
    centeredSlides: true,
    autoplay: {
      delay: 2500,
      disableOnInteraction: false,
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });
  $(".menuopen").click(function(){
    $(".nav").animate({width:'toggle'});
    $(".bg").animate({width:'toggle'});
  });
  $(".close").click(function(){
    $(".nav").animate({width:'toggle'});
    $(".bg").animate({width:'toggle'});
    $(".nav .m1 li").slideUp();
    $(".nav .m2 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".nav ul li").hide();
  $(".m1").click(function(){
    $(".nav .m1 li").slideToggle('slow',function(){
    });
    $(".nav .m2 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".m2").click(function(){
    $(".nav .m2 li").slideToggle('slow',function(){
    });
    $(".nav .m1 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".m3").click(function(){
    $(".nav .m3 li").slideToggle('slow',function(){
    });
    $(".nav .m2 li").slideUp();
    $(".nav .m1 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".m4").click(function(){
    $(".nav .m4 li").slideToggle('slow',function(){
    });
    $(".nav .m2 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m1 li").slideUp();
  });
  $(".complete").hide();
  $(".getnews").click(function(){
    $(".getnews").hide();
    $(".complete").show();
  });
  $(".name input").click(function(){
    $(".complete").hide();
    $(".getnews").show();
  });
  $(document).ready(function(){
    if($(window).width() < 641){
        $('.slider').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
        });
    }
    else if($(window).width() > 640){
        $('.slider').slick('unslick');
    }
});