$(".menuopen").click(function(){
    $(".nav").animate({width:'toggle'});
    $(".bg").animate({width:'toggle'});
  });
  $(".close").click(function(){
    $(".nav").animate({width:'toggle'});
    $(".bg").animate({width:'toggle'});
    $(".nav .m1 li").slideUp();
    $(".nav .m2 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".nav ul li").hide();
  $(".m1").click(function(){
    $(".nav .m1 li").slideToggle('slow',function(){
    });
    $(".nav .m2 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".m2").click(function(){
    $(".nav .m2 li").slideToggle('slow',function(){
    });
    $(".nav .m1 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".m3").click(function(){
    $(".nav .m3 li").slideToggle('slow',function(){
    });
    $(".nav .m2 li").slideUp();
    $(".nav .m1 li").slideUp();
    $(".nav .m4 li").slideUp();
  });
  $(".m4").click(function(){
    $(".nav .m4 li").slideToggle('slow',function(){
    });
    $(".nav .m2 li").slideUp();
    $(".nav .m3 li").slideUp();
    $(".nav .m1 li").slideUp();
  });
  $(".bg").hide();
  $(".complete").hide();
  $(".getnews").click(function(){
    $(".getnews").hide();
    $(".complete").show();
  });
  $(".name input").click(function(){
    $(".complete").hide();
    $(".getnews").show();
  });
  var swiper = new Swiper('.swiper-container', {
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
      renderBullet: function (index, className) {
        return '<span class="' + className + '">' + (index + 1) + '</span>';
      },
    },
  });
  $(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
            $('#MOVE_TOP_BTN').fadeIn();
        } else {
            $('#MOVE_TOP_BTN').fadeOut();
        }
    });
    
    $("#MOVE_TOP_BTN").click(function() {
        $('html, body').animate({
            scrollTop : 0
        }, 600);
        return false;
    });
});